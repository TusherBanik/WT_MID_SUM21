<html>
<head>
	<title>Form</title>
</head>
<body>
                <form>
                	  <table align="center" border="2">
                             <tr>
                             	 <th colspan="3">Booked room</th>
                             </tr>
                	  	     <tr>
                	  	     	 <td>Please Enter Your Room number</td>
                	  	     	 <td> <input type="value" placeholder="Room number"> </td>
                	  	     </tr>
							 <tr>
                	  	     	 <td>Please Enter Your booking time</td>
                	  	     	 <td> <input type="value" placeholder="booking time"> </td>
                	  	     </tr>
							 <tr>
                	  	     	 <td>Please Enter Your Payment Amount</td>
                	  	     	 <td> <input type="value" placeholder="Payment Amount"> </td>
								 <td><select><option>AM<option><option>PM<option></select></td>
                	  	     </tr>
							 <tr>
						<td>Payment System  </td>
						<td>
							<select>
							    <option>Cash</option>
								<option>Bkash</option>
								<option>Rocket</option>
								<option>VisaCard</option>
								
							</select> 
							</tr>
							<tr>
                	  	     	 <td>Customer Id:</td>
                	  	     	 <td> <input type="value" placeholder="Customer Id"> </td>
                	  	     </tr>
                           
                             <tr>
						     <td align="center" colspan="2"><input type="submit" value="Login"></td>
							 
					        </tr>
                	  </table>
                </form>   	
</body>
</html>