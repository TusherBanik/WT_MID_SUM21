<html>
	<head> <title> test </title> </head>
		<body>
			<form action = "submitted.php" method = "post">
				<table border = "2">
					<tr>
						<td>
						Name:
						</td>
						
						<td>
						<input type="text" name="name" placeholder= "Name" >
						</td>
					</tr>
					
					<tr>
						<td>
						username:
						</td>
						
						<td>
						<input type="text" name="username"placeholder= "User Name" >
						</td>
					</tr>
					<tr>
						<td>
						Email Address:
						</td>
						
						<td>
						<input type="text" name="Email" placeholder= "Email" >
						</td>
					</tr>
					<tr>
						<td>
						Your NID number :
						</td>
						
						<td>
						<input type="value" name="nid number" placeholder= "nid number" >
						</td>
					</tr>
					
					<tr>
						<td>
						Your Current Address :
						</td>
						
						<td>
						<input type="text" name="Email" placeholder= "Email" >
						</td>
					</tr>
					
					<tr>
						<td>
						Gender :
						</td>
						
						<td>
						<input type="radio" value = "male"  name="gender" > Male <input type="radio" value="female" name = "gender"  > Female
						</td>
					</tr>
					
					<tr>
						<td>
						Type of Membership
						</td>
						
						<td>
						<select name="profession">
							
							<option>Diamond</option>
							<option>Gold</option>
							<option>Sylver</option>
							<option>Premium</option>
							<option>N/A</option>
						</select>
						</td>
					</tr>
					
					<tr>
						<td>
						Bio:
						</td>
						
						<td>
						<textarea name="bio"></textarea>
						
						
						</td>
					</tr>
					
					<tr>
						<td colspan = "2" align = "left">
						
							<input type = "submit" value="submit">
						</td>
						
					</tr>
					
				</table>
			</form>
		</body>
</html>