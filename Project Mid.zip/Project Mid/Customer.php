<?php
$name="";
$err_name="";
$street="";
$err_street="";
$city="";
$err_city="";
$state="";
$err_state="";
$zip="";
$err_zip="";   
$nidno="";
$err_nidno=""; 
$number="";
$err_number="";
$email="";
$err_email="";
$id="";
$err_info="";
$err=false;

function hearExist($hears){
		global $hear;
		foreach($hear as $h){
			if($h == $hears){
				return true;
			}
		}
		return false;
	}
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		
		if(empty($_POST["name"])){
			$err_name="Name Required";
			$err=true;
		}
		else{
			$name=$_POST["name"];
		}
		if(empty($_POST["street"])){
			$err_street="Street Number Required";
			$err = true;
		}
		else{
			$street = $_POST["street"];
		}
		if(empty($_POST["city"])){
			$err_city="City Required";
			$err = true;
		}
		else{
			$city = $_POST["city"];
		}
		if(empty($_POST["state"])){
			$err_state="State Required";
			$err = true;
		}
		else{
			$state = $_POST["state"];
		}
		if(empty($_POST["zip"])){
			$err_zip="Postal/Zip Required";
			$err = true;
		}
		else{
			$zip = $_POST["zip"];
		}
		if(empty($_POST["nidno"])){
			$err_number="nidnoRequired";
			$err = true;
		}
		else{
			$number = $_POST["nidno"];
		}
		
		if(empty($_POST["number"])){
			$err_number="Number Required";
			$err = true;
		}
		else{
			$number = $_POST["number"];
		}
		if(!strpos($_POST["email"],"@")){
			if(!strpos($_POST["email"],"."))
			$err_email="Email should contain '@' and '.' sequentially";
			}
		else {
			$email=$_POST["email"];
		}
		if(empty($_POST["id"])){
			$err_id="id Required";
			$err = true;
		}
		else{
			$id = $_POST["id"];
		}
		if(!$err){
			echo "Name: ".htmlspecialchars($_POST["name"])."<br>";
			echo "Street: ".htmlspecialchars($_POST["street"])."<br>";
			echo "City: ".htmlspecialchars($_POST["city"])."<br>";
			echo "State: ".htmlspecialchars($_POST["state"])."<br>";
			echo "Zip: ".htmlspecialchars($_POST["zip"])."<br>";
			echo "Code: ".htmlspecialchars($_POST["code"])."<br>";
			echo "nidno: ".htmlspecialchars($_POST["nidno"])."<br>";
			echo "Code: ".htmlspecialchars($_POST["code"])."<br>";
			echo "Number: ".htmlspecialchars($_POST["number"])."<br>";
			echo "Email: ".htmlspecialchars($_POST["email"])."<br>";
			
			
			foreach($arr as $e){
				echo "$e <br>";
			}
			
			echo "id: ".htmlspecialchars($_POST["id"])."<br>";
		}
		
	}
?>
<html>
<head></head>
<body>
<h1>Customer details</h1>

<form action="" method="post">
<table>
                <tr>
					<td>Enter your Name </td>
					<td><b>:</b></td>
					<td><input type="text" name="name" value="<?php echo $name;?>" placeholder="Name"></td>
					<td><span><?php echo $err_name;?></span></td>
				</tr>
				<tr>
					<td>Enter your Address </td>
					<td><b>:</b></td>
					<td><input type="text" name="street" value="<?php echo $street;?>" placeholder="Street Number"><br>
					<input type="text" name="city" value="<?php echo $city;?>" placeholder="City"> -
					<input type="text" name="state" value="<?php echo $state;?>" placeholder="State"><br>
					<input type="text" name="zip" value="<?php echo $zip;?>" placeholder="Postal/Zip code">
					</td>
					<td><span><?php echo $err_street;?></span></td><td><span><?php echo $err_city;?></span></td><td><span><?php echo $err_state;?></span></td><td><span><?php echo $err_zip;?></span></td>
				</tr>
				<tr>
					<td>Enter your NID NO </td>
					<td><b>:</b></td>
					<td><input type="nidno" name="nidno" value="<?php echo $nidno;?>" placeholder="nidno"></td>
					<td><span><?php echo $err_nidno;?></span></td>
				</tr>
				<tr>
						<td>Enter your Phone No </td>
						<td><b>:</b></td>
					<td><input type="tel" name="number" value="<?php echo $number;?>" placeholder="number"></td>
						
						<td><span><?php echo $err_number;?></span></td>
				  
				</tr>
				<tr>
					<td>Enter your Email </td>
					<td><b>:</b></td>
					<td><input type="text" name="email" value="<?php echo $email;?>" placeholder="Email"></td>
					<td><span><?php echo $err_email;?></span></td>
				</tr>
				<tr>
					<td>Information </td>
					<td><b>:</b></td>
					<td><input type="text" name="Write your information" text="<?php echo $info;?>" placeholder="Write your information"></td>
					<td><span><?php echo $err_info;?></span></td>
				</tr>
					
				<tr>
					<td align="center" colspan="3"><input type="submit" name="submit"value="Register"></td>
				
				</tr>

</table>

</body>
</html>
	
	
	
		
			
			 
				