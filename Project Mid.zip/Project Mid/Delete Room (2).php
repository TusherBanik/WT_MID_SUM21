<html>
	<head> <title> test </title> </head>
		<body>
			<form action = "submitted.php" method = "post">
				<table border = "2">
					
					<tr>
						<td>
					    Room number :
						</td>
					<td>
						<input type="value" name="Room number" placeholder= "Room number" >
						</td>
					</tr>
						<td>
						Reason leave room:
						</td>
						
						<td>
						<textarea name="bio"></textarea>
						
						
						</td>
					</tr>
					
					<tr>
						<td colspan = "2" align = "left">
						
							<input type = "submit" value="submit">
						</td>
						
					</tr>
					
				</table>
			</form>
		</body>
</html>