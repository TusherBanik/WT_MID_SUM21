<html>
		<body>
		<h1> Room deleated... </h1>
			<?php
				    echo $_POST[" Room number :"] ."<br>";
				    echo $_POST["Reason leave room:"];
			?>
			
			</body>
		
</html>