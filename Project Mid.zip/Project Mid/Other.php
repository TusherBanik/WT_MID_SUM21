<html>
<body>
<ul>
<img width="450px" height="450px" src="pic.jpg">
<hr>
<a target ="_blank" href ="new room.php">new room.php</a>
<hr>
<a target ="_blank" href ="Delete room.php">Delete room.php</a>
<hr>
<a target ="_blank" href ="Booked room.php">Booked room.php</a>
<hr>
<a target ="_blank" href ="Customer.php">Customer</a>
<hr>
<a target ="_blank" href ="Create Mambership.php">Create Mambership.php</a>
<hr>
<a target ="_blank" href ="TypeRooms.php">TypeRooms.php</a>
</body>
</html>