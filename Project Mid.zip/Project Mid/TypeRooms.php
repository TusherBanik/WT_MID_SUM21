<html>
<body>
<ul>
<img width="250px" height="250px" src="super king.jpg">
<hr>
<a target ="_blank" href ="new room.php">Booked room.php</a>
<hr>
<img width="250px" height="250px" src="laxary.jpg">
<hr>
<a target ="_blank" href ="Booked room.php">Booked room.php</a>
<hr>
<img width="250px" height="250px" src="Marchant.jpg">
<hr>
<a target ="_blank" href ="new room.php">Booked room.php</a>
<hr>
<img width="250px" height="250px" src="traditional.jpg">
<hr>
<a target ="_blank" href ="Booked room.php">Booked room.php</a>
<hr>
<img width="250px" height="250px" src="VIP 1.jpg">
<hr>
<a target ="_blank" href ="new room.php">Booked room.php</a>
<hr>
<img width="250px" height="250px" src="family vip.jpg">
<hr>
<a target ="_blank" href ="Booked room.php">Booked room.php</a>
<hr>
</body>
</html>