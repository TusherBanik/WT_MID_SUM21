<html>
<head>
	<title>Form</title>
</head>
<body>
                <form action = "other.php" method ="post">
                	  <table align="center" border="2">
                             <tr>
                             	 <th colspan="3">Admin</th>
                             </tr>
                	  	     <tr>
                	  	     	 <td>Please Enter Your ID</td>
                	  	     	 <td> <input type="text" placeholder="ID"> </td>
                	  	     </tr>
							 <tr>
                	  	     	 <td>Please Enter Your Name</td>
                	  	     	 <td> <input type="text" placeholder="Name"> </td>
                	  	     </tr>
                              <tr>
                	  	     	 <td>Please Enter Your UserName</td>
                	  	     	 <td> <input type="text" placeholder="Name"> </td>
                	  	     </tr

                	  	     <tr>
                	  	     	 <td>Password:</td>
                	  	     	 <td> <input type="Password" placeholder="Password"> </td>
                	  	     </tr>
                             <tr>
						     <td align="center" colspan="2"><input type="submit" value="Login"></td>
							 
					        </tr>
							<tr>
                             <td colspan = 3><p style="text-align:right"><a target="_blank" href="Forget password.php">Forget password</a></p></td>
                           </tr>
                	  </table>
                </form>   	
</body>
</html>