<html>
<head>
	<title>Form</title>
</head>
<body>
                <form>
                	  <table align="center" border="2">
                             <tr>
                             	 <th colspan="3">New Room</th>
                             </tr>
                	  	     <tr>
                	  	     	 <td>Please Enter Room Number</td>
                	  	     	 <td> <input type="text" placeholder="Room No"> </td>
                	  	     </tr>
							 <tr>
                	  	     	 <td>Please Enter floor</td>
                	  	     	 <td> <input type="text" placeholder="Floor No"> </td>
                	  	     </tr>
                              <tr>
                	  	     	 <td>Please Enter Unit</td>
                	  	     	 <td> <input type="text" placeholder="Unit"> </td>
                	  	     </tr

                             <tr>
						     <td align="center" colspan="2"><input type="submit" value="Next"></td>
					        </tr>
                	  </table>
                </form>   	
</body>
</html>