<html>
	<head></head>
	<body>
		<fieldset>
			<form>
				<table>
				    <tr>
						<th align="center" >Review and Feedback Section: </th>
						
					</tr>
					<tr>
						<td>Enter Your Id: </td>
						<td><input type="value" placeholder="Value required"></td>
					</tr>
					<tr>
						<td>Enter Your Name: </td>
						<td><input type="text" placeholder="Name required"></td>
					</tr>
					<tr>
						<td>Enter Your E-mail: </td>
						<td><input type="text" placeholder="Email required"></td>
					</tr>
					<tr>
						<td>Types:  </td>
						<td>
							<select>
							    <option>Compliment</option>
								<option>General enquiry</option>
								<option>Suggestion</option>
								<option>Complain</option>
							</select> 
						</td>
					</tr>
					<tr>
						<td>Ratting:  </td>
						<td>
							<select>
							    <option>*****</option>
								<option>****</option>
								<option>***</option>
								<option>Overall</option>
							</select> 
						</td>
					<tr>
						<td>Your Message: </td>
						<td> <textarea></textarea> </td>
					</tr>
					</tr>
					<tr>
						<td align="center" >
						<input type="submit" value="Send">
						</td>
					</tr>
				</table>
			</form>
		</fieldset>
	</body>
</html>