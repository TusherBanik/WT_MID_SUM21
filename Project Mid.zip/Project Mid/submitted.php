<html>
		<body>
		<h1> submitted </h1>
			<?php
				echo $_POST["name"] ."<br>";
				echo $_POST["username"] ."<br>";
				echo $_POST["Email"] ."<br>";
				echo $_POST["gender"] . "<br>" ;
				echo $_POST["bio"];
			?>
			
			</body>
		
</html>